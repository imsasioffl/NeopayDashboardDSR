#!/usr/bin/env node
/**
 * generate.js
 * ---------------------------------------------------------------------------
 * CLI entry point.
 *
 *   node generate.js [input.json] [output.txt]
 *
 * Defaults to sample/sample-input.json -> output/VISAin-generated.txt
 */

'use strict';

const fs = require('fs');
const path = require('path');
const VisaInGenerator = require('./lib/VisaInGenerator');
const { RecordValidationError } = require('./lib/recordBuilder');

function main() {
  const inputPath = process.argv[2] || path.join(__dirname, 'sample', 'sample-input.json');
  const outputPath = process.argv[3] || path.join(__dirname, 'output', 'VISAin-generated.txt');

  const input = JSON.parse(fs.readFileSync(inputPath, 'utf8'));

  const generator = new VisaInGenerator(input.fileHeader);

  for (const txn of input.transactions) {
    generator.addTransaction(txn);
  }

  const fileContent = generator.generateFile();

  fs.mkdirSync(path.dirname(outputPath), { recursive: true });
  fs.writeFileSync(outputPath, fileContent, 'latin1');

  const summary = generator.getSummary();
  console.log('Generated:', outputPath);
  console.log('Summary:', summary);

  // Structural self-check: every line (minus the CRLF) must be exactly 168.
  const lines = fileContent.split('\r\n').filter((l) => l.length > 0);
  const bad = lines.filter((l) => l.length !== 168);
  if (bad.length) {
    console.error(`WARNING: ${bad.length} record(s) are not 168 characters wide.`);
    process.exitCode = 1;
  } else {
    console.log(`All ${lines.length} records are exactly 168 characters wide.`);
  }
}

try {
  main();
} catch (err) {
  if (err instanceof RecordValidationError) {
    console.error('Validation error:', err.message);
    process.exitCode = 1;
  } else {
    throw err;
  }
}
