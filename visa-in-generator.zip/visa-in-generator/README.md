# Visa In (BASE II TCx) Processing File Generator

Node.js generator that builds fixed-width Visa In files from the field
layout defined in `processingV.xlsx`. Read this file before changing
anything in `config/layout.js` — that file is the single source of truth
for byte positions and should never be hand-edited without re-checking it
against the sheet.

## 1. Comparison analysis (Excel layout vs. sample .txt)

Before writing any code, the Excel layout (`VISAIN - Transaction
Validation` sheet) was mapped field-by-field and cross-checked against
`VISAin-processing.txt`. Key findings:

- **Every record type is 168 characters wide.** TCR0, TCR1, TCR5, TCR4,
  TC90, TC91 and TC92 all resolve to `start + length - 1 = 168` for their
  last field. This matches the standard VisaNet BASE II 168-byte TC record
  and is used as `RECORD_LENGTH` throughout the code.
- **The sample .txt is CRLF-terminated with a blank line after every
  record** (`record\r\n\r\n`). Several records in the sample are 1–7
  bytes shorter than 168 (e.g. the TC92 trailer is only 161 bytes). This is
  trailing-whitespace trimming introduced when the file was saved/copied,
  **not** a real Prime-accepted length — trailing space is significant in a
  fixed-width record and must not be trimmed. The generator always emits
  the full 168 bytes, spaces included.
- **Record separator used by the generator:** `\r\n` after each record,
  with **no blank line** between records (the blank lines in the sample
  appear to be an artifact of how the reference file was exported, not a
  Prime requirement — fixed-width batch formats are normally one record
  per line with no gaps). If your Prime intake expects a bare `\n` or no
  blank lines are tolerated differently, change `LINE_TERMINATOR` in
  `lib/VisaInGenerator.js` — it's the only place that decision lives.
- **TCR0 / TCR1 / TCR5 / TCR4 field positions** were taken verbatim from
  the "Start"/"Length" columns of the Excel sheet (columns C/D, I/J, N/O,
  S/T respectively). TC90 / TC91 / TC92 similarly from AF/AG, AK/AL, AP/AQ.
- **Data type (numeric vs. alphanumeric)** was not reliably inferred from
  the sheet's "Sample" values, because the template row uses `0`-filled
  placeholders for numeric *and* text fields alike. Types in
  `config/layout.js` are instead assigned from field semantics (amounts,
  counts, dates, codes → numeric/zero-padded left; names, cities, free
  text → alphanumeric/space-padded right), consistent with standard
  VisaNet TCR0/TCR1/TCR5 documentation. **Re-verify against your
  processor's actual field spec before production use**, particularly for
  Reference Number / Terminal ID / Member ID, which some issuers treat as
  alphanumeric even though this sample's data is all-digit.
- **Constant fields** (Transaction Code Qualifier, Rate Table ID, Fee
  Program Indicator, Network ID Code, Business Format Code, etc.) were
  identified where every occurrence in the sample file used the same
  value, and are hardcoded as `constant` entries in the layout so they can
  never be accidentally overwritten by a caller.

## 2. Project structure

```
visa-in-generator/
├── config/
│   └── layout.js          Field-position layout for all 7 record types (source of truth)
├── lib/
│   ├── utils.js            padLeft, padRight, formatAmount, formatDate, formatJulianDate
│   ├── recordBuilder.js     Generic layout-driven record assembly + field validation
│   ├── builders.js          buildTCR0 / buildTCR1 / buildTCR4 / buildTCR5 / buildTC90 / buildTC91 / buildTC92
│   ├── VisaInGenerator.js   Class: addTransaction(), generateFile(), trailer calc
│   └── validate.js          Structural validation for generated or received files
├── sample/
│   └── sample-input.json    Example transaction input
├── output/                  Generated files land here
└── generate.js               CLI entry point
```

## 3. Usage

```bash
node generate.js                                   # sample/sample-input.json -> output/VISAin-generated.txt
node generate.js my-transactions.json my-file.txt   # custom input/output
```

Programmatic usage:

```js
const VisaInGenerator = require('./lib/VisaInGenerator');

const generator = new VisaInGenerator({
  centerInformationBlock: '045489',
  processingDate: new Date(),
  batchNumber: '1',
});

generator
  .addTransaction({
    transactionType: '05',       // Domestic retail sale
    pan: '4198682470556100000',
    amount: 4270.00,
    currency: '784',
    merchantName: 'ZURICH',
    merchantCity: 'VEGAS',
    merchantCountry: 'AE',
    mcc: '5411',
    authCode: '112287',
    rrn: '74646956117343148317283',
    stan: '419565',
    terminalId: '00000161',
    memberId: '00000000',
  })
  .addTransaction({ /* ... */ });

const fileContent = generator.generateFile();
```

## 4. Validating a file

```js
const { validateFileStructure } = require('./lib/validate');
const fs = require('fs');

const content = fs.readFileSync('output/VISAin-generated.txt', 'latin1');
console.log(validateFileStructure(content));
// { valid: true, recordCount: 11, errors: [] }
```

`validateFileStructure` flags any record that isn't exactly 168
characters. `buildRecord()` (used internally by every `buildTCRx`/`buildTC9x`
function) additionally throws a `RecordValidationError` naming the exact
field, its byte range, and the offending value if:

- a numeric (`type: 'N'`) field receives non-digit input,
- any field's value is longer than its declared `length`.

## 5. Dynamic vs. constant fields

Only these are ever supplied per-transaction (everything else in the
layout is either a fixed constant or a structural filler):

| Field | Source |
|---|---|
| PAN | `txn.pan` |
| Expiry | *(not present in this layout's TCR0/TCR1/TCR5 — add a field if your variant carries it)* |
| Processing/Purchase Date | `txn.purchaseDate` / file header `processingDate` |
| Amount | `txn.amount` |
| Currency | `txn.currency` |
| Merchant Name/City/Country | `txn.merchantName/City/Country` |
| MCC | `txn.mcc` |
| Auth Code | `txn.authCode` |
| RRN | `txn.rrn` |
| STAN | `txn.stan` |
| Sequence Number | assigned automatically by `addTransaction()` |
| Terminal ID | `txn.terminalId` |
| Transaction Type | `txn.transactionType` |

## 6. Trailer generation

`VisaInGenerator._computeTotals()` walks every queued transaction once and
derives, with no manual arithmetic required by the caller:

- total transaction count,
- monetary transaction count (based on `MONETARY_TRANSACTION_CODES`),
- destination/source amount totals,
- TCR count (`transactions.length * recordsPerTransaction`).

Both `buildTC91` (batch trailer) and `buildTC92` (file trailer) consume the
same totals object — for a single-batch file they are identical except for
the transaction-code constant, matching the sample file's TC91/TC92 pair.
If you need multiple batches per file, call `_computeTotals()` per batch
and only run a single file-level accumulation into `buildTC92` once, at
the end.
