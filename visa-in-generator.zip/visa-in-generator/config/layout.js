/**
 * layout.js
 * ---------------------------------------------------------------------------
 * Field-position layout for every Visa In (BASE II / TCx) record type,
 * extracted field-by-field from processingV.xlsx ("VISAIN - Transaction
 * Validation" sheet). This is the single source of truth for byte
 * positions. Nothing in this file should be "eyeballed" against the sample
 * .txt again -- if the layout changes, update ONLY here.
 *
 * Every record type is 168 characters wide (start=1, end=168), which lines
 * up with the standard VisaNet BASE II 168-byte TC record.
 *
 * type:
 *   "N"  = numeric, zero-padded LEFT (right justified)   e.g. amounts, counts, dates
 *   "A"  = alphanumeric, space-padded RIGHT (left justified) e.g. names, cities, free text
 *   "F"  = filler / reserved, always spaces unless a constant is supplied
 *
 * start/length are 1-indexed exactly as given in the Excel template.
 */

'use strict';

const RECORD_LENGTH = 168;

// Each field: { name, start, length, type, constant? }
// "constant" (if present) is written verbatim every time and is never a
// dynamic input field.

const TCR0 = [
  { name: 'transactionCode', start: 1, length: 2, type: 'N' },
  { name: 'transactionCodeQualifier', start: 3, length: 1, type: 'N', constant: '0' },
  { name: 'sequenceNumber', start: 4, length: 1, type: 'N' },
  { name: 'accountNumber', start: 5, length: 19, type: 'N' }, // PAN
  { name: 'floorLimitIndicator', start: 24, length: 1, type: 'A', constant: '0' },
  { name: 'cwbCrbIndicator', start: 25, length: 1, type: 'A', constant: '0' },
  { name: 'lcsIndicator', start: 26, length: 1, type: 'A', constant: '0' },
  { name: 'referenceNumber', start: 27, length: 23, type: 'N' }, // RRN
  { name: 'memberId', start: 50, length: 8, type: 'N' },
  { name: 'purchaseDate', start: 58, length: 4, type: 'N' },
  { name: 'destinationAmount', start: 62, length: 12, type: 'N' },
  { name: 'destinationCurrency', start: 74, length: 3, type: 'N' },
  { name: 'sourceAmount', start: 77, length: 12, type: 'N' },
  { name: 'sourceCurrency', start: 89, length: 3, type: 'N' },
  { name: 'merchantName', start: 92, length: 25, type: 'A' },
  { name: 'merchantCity', start: 117, length: 13, type: 'A' },
  { name: 'merchantCountry', start: 130, length: 3, type: 'A' },
  { name: 'mcc', start: 133, length: 4, type: 'N' },
  { name: 'merchantPostalCode', start: 137, length: 5, type: 'N', constant: '00000' },
  { name: 'stateProvince', start: 142, length: 3, type: 'A' },
  { name: 'reqPayServiceIndicator', start: 145, length: 1, type: 'A' },
  { name: 'paymentForms', start: 146, length: 1, type: 'A' },
  { name: 'usageCode', start: 147, length: 1, type: 'N', constant: '0' },
  { name: 'chargeBackReason', start: 148, length: 2, type: 'N', constant: '00' },
  { name: 'settleFlag', start: 150, length: 1, type: 'N', constant: '0' },
  { name: 'baseServiceIndicator', start: 151, length: 1, type: 'A' },
  { name: 'authCode', start: 152, length: 6, type: 'A' },
  { name: 'posTerminal', start: 158, length: 1, type: 'A' },
  { name: 'reserved1', start: 159, length: 1, type: 'F' },
  { name: 'cardId', start: 160, length: 1, type: 'A' },
  { name: 'collectOnlyFlag', start: 161, length: 1, type: 'A' },
  { name: 'posEntryMode', start: 162, length: 2, type: 'A' },
  { name: 'centralJulianDate', start: 164, length: 4, type: 'F' },
  { name: 'reimbursementAttribute', start: 168, length: 1, type: 'A' },
];

const TCR1 = [
  { name: 'transactionCode', start: 1, length: 2, type: 'N' },
  { name: 'transactionCodeQualifier', start: 3, length: 1, type: 'N', constant: '0' },
  { name: 'componentSequenceNumber', start: 4, length: 1, type: 'N', constant: '1' },
  { name: 'businessFormatCode', start: 5, length: 1, type: 'A' },
  { name: 'tokenAssuranceLevel', start: 6, length: 2, type: 'F' },
  { name: 'rateTableId', start: 8, length: 5, type: 'A', constant: 'A0139' },
  { name: 'reserved1', start: 13, length: 4, type: 'F' },
  { name: 'reserved2', start: 17, length: 6, type: 'N', constant: '000000' },
  { name: 'documentationIndicator', start: 23, length: 1, type: 'A' },
  { name: 'memberMessageText', start: 24, length: 50, type: 'A' },
  { name: 'specialConditionIndicator', start: 74, length: 2, type: 'F' },
  { name: 'feeProgramIndicator', start: 76, length: 3, type: 'N', constant: '859' },
  { name: 'issuerCharge', start: 79, length: 1, type: 'A', constant: 'S' },
  { name: 'persistentFxAppliedIndicator', start: 80, length: 1, type: 'A', constant: 'N' },
  { name: 'cardAcceptorId', start: 81, length: 15, type: 'A' },
  { name: 'terminalId', start: 96, length: 8, type: 'N' },
  { name: 'nationalReimbursementFee', start: 104, length: 12, type: 'N', constant: '000000000000' },
  { name: 'mailPhoneEcommIndicator', start: 116, length: 1, type: 'N' },
  { name: 'specialChargebackIndicator', start: 117, length: 1, type: 'F' },
  { name: 'conversionDate', start: 118, length: 4, type: 'N' },
  { name: 'reserved3', start: 122, length: 2, type: 'F' },
  { name: 'acceptanceTerminalIndicator', start: 124, length: 1, type: 'F' },
  { name: 'prepaidCardIndicator', start: 125, length: 1, type: 'F' },
  { name: 'serviceDevelopmentField', start: 126, length: 1, type: 'F' },
  { name: 'avsResponseCode', start: 127, length: 1, type: 'F' },
  { name: 'authorizationSourceCode', start: 128, length: 1, type: 'F' },
  { name: 'purchaseIdentifierFormat', start: 129, length: 1, type: 'F' },
  { name: 'accountSelection', start: 130, length: 1, type: 'N', constant: '0' },
  { name: 'installmentPaymentCount', start: 131, length: 2, type: 'F' },
  { name: 'purchaseIdentifier', start: 133, length: 25, type: 'A' },
  { name: 'cashback', start: 158, length: 9, type: 'N', constant: '000000000' },
  { name: 'chipConditionCode', start: 167, length: 1, type: 'F' },
  { name: 'posEnvironment', start: 168, length: 1, type: 'F' },
];

const TCR5 = [
  { name: 'transactionCode', start: 1, length: 2, type: 'N' },
  { name: 'transactionCodeQualifier', start: 3, length: 1, type: 'N', constant: '0' },
  { name: 'componentSequenceNumber', start: 4, length: 1, type: 'N', constant: '5' },
  { name: 'transactionIdentifier', start: 5, length: 15, type: 'N' },
  { name: 'authorizedAmount', start: 20, length: 12, type: 'N', constant: '000000000000' },
  { name: 'authorizationCurrencyCode', start: 32, length: 3, type: 'F' },
  { name: 'authorizationResponseCode', start: 35, length: 2, type: 'F' },
  { name: 'validationCode', start: 37, length: 4, type: 'F' },
  { name: 'excludedTcIdentifierReason', start: 41, length: 1, type: 'F' },
  { name: 'reserved1', start: 42, length: 1, type: 'F' },
  { name: 'reserved2', start: 43, length: 2, type: 'F' },
  { name: 'multipleClearingSeqNumber', start: 45, length: 2, type: 'N', constant: '00' },
  { name: 'multipleClearingSeqCount', start: 47, length: 2, type: 'N', constant: '00' },
  { name: 'marketSpecificAuthDataIndicator', start: 49, length: 1, type: 'F' },
  { name: 'totalAuthorizedAmount', start: 50, length: 12, type: 'N', constant: '000000000000' },
  { name: 'informationIndicator', start: 62, length: 1, type: 'F' },
  { name: 'merchantTelephoneNumber', start: 63, length: 14, type: 'F' },
  { name: 'additionalDataIndicator', start: 77, length: 1, type: 'F' },
  { name: 'merchantVolumeIndicator', start: 78, length: 2, type: 'F' },
  { name: 'electronicCommerceGoodsIndicator', start: 80, length: 2, type: 'F' },
  { name: 'merchantVerificationValue', start: 82, length: 10, type: 'F' },
  { name: 'interchangeFeeAmount', start: 92, length: 15, type: 'N', constant: '000000000000000' },
  { name: 'interchangeFeeSign', start: 107, length: 1, type: 'A', constant: 'D' },
  { name: 'sourceToBaseExchangeRate', start: 108, length: 8, type: 'N', constant: '00000000' },
  { name: 'baseToDestExchangeRate', start: 116, length: 8, type: 'N', constant: '00000000' },
  { name: 'optionalIssuerIsaAmount', start: 124, length: 12, type: 'N', constant: '000000000000' },
  { name: 'productId', start: 136, length: 2, type: 'A' },
  { name: 'programId', start: 138, length: 6, type: 'F' },
  { name: 'dccIndicator', start: 144, length: 1, type: 'F' },
  { name: 'accountTypeIdentification', start: 145, length: 4, type: 'F' },
  { name: 'spendQualifiedIndicator', start: 149, length: 1, type: 'F' },
  { name: 'panToken', start: 150, length: 16, type: 'N' },
  { name: 'reserved3', start: 166, length: 2, type: 'F' },
  { name: 'cvv2ResultCode', start: 168, length: 1, type: 'F' },
];

const TCR4 = [
  { name: 'transCd', start: 1, length: 2, type: 'N' },
  { name: 'tcQualifier', start: 3, length: 1, type: 'N', constant: '0' },
  { name: 'seqNumber', start: 4, length: 1, type: 'N', constant: '4' },
  { name: 'agentUniqueId', start: 5, length: 5, type: 'F' },
  { name: 'filler1', start: 10, length: 5, type: 'F' },
  { name: 'busFormatCd', start: 15, length: 2, type: 'A', constant: 'SD' },
  { name: 'networkIdCode', start: 17, length: 4, type: 'N', constant: '0002' },
  { name: 'dbContForInfo', start: 21, length: 25, type: 'A' },
  { name: 'adjustProcIndic', start: 46, length: 1, type: 'F' },
  { name: 'msgRsnCode', start: 47, length: 4, type: 'F' },
  { name: 'surchargeAmt', start: 51, length: 8, type: 'N', constant: '00000000' },
  { name: 'surchgCrDbIndic', start: 59, length: 2, type: 'F' },
  { name: 'filler2', start: 61, length: 16, type: 'F' },
  { name: 'adnlTxnFeeAmt1', start: 77, length: 8, type: 'N', constant: '00000000' },
  { name: 'adnlTxnFeeAmt2', start: 85, length: 8, type: 'N', constant: '00000000' },
  { name: 'totalDiscountAmt', start: 93, length: 8, type: 'N', constant: '00000000' },
  { name: 'filler3', start: 101, length: 3, type: 'F' },
  { name: 'surchargeInChCurr', start: 104, length: 8, type: 'N', constant: '00001000' },
  { name: 'mnyXfrFgnXchgFee', start: 112, length: 8, type: 'N', constant: '00001000' },
  { name: 'payAcctRef', start: 120, length: 29, type: 'A' },
  { name: 'tokenReqId', start: 149, length: 11, type: 'N' },
  { name: 'filler4', start: 160, length: 9, type: 'F' },
];

const TC90 = [
  { name: 'transactionCode', start: 1, length: 2, type: 'N', constant: '90' },
  { name: 'centerInformationBlock', start: 3, length: 6, type: 'N' },
  { name: 'processingDate', start: 9, length: 5, type: 'N' }, // YYDDD (Julian)
  { name: 'reserved1', start: 14, length: 6, type: 'F' },
  { name: 'settlementDate', start: 20, length: 5, type: 'F' },
  { name: 'reserved2', start: 25, length: 2, type: 'F' },
  { name: 'releaseNumber', start: 27, length: 3, type: 'F' },
  { name: 'testOption', start: 30, length: 4, type: 'F' },
  { name: 'reserved3', start: 34, length: 29, type: 'F' },
  { name: 'securityCode', start: 63, length: 8, type: 'F' },
  { name: 'reserved4', start: 71, length: 6, type: 'F' },
  { name: 'incomingFileId', start: 77, length: 3, type: 'F' },
  { name: 'reserved5', start: 80, length: 89, type: 'F' },
];

const TC91 = [
  { name: 'transactionCode', start: 1, length: 2, type: 'N', constant: '91' },
  { name: 'transactionCodeQualifier', start: 3, length: 1, type: 'N', constant: '0' },
  { name: 'componentSequenceNumber', start: 4, length: 1, type: 'N', constant: '0' },
  { name: 'centerInformationBlock', start: 5, length: 6, type: 'N' },
  { name: 'processingDate', start: 11, length: 5, type: 'N' },
  { name: 'destinationAmount', start: 16, length: 15, type: 'N' }, // batch total (calculated)
  { name: 'numberOfMonetaryTransactions', start: 31, length: 12, type: 'N' }, // calculated
  { name: 'batchNumber', start: 43, length: 6, type: 'N' },
  { name: 'numberOfTcrs', start: 49, length: 12, type: 'N' }, // calculated
  { name: 'reserved1', start: 61, length: 6, type: 'N', constant: '000000' },
  { name: 'centreBatchId', start: 67, length: 8, type: 'F' },
  { name: 'numberOfTransactions', start: 75, length: 9, type: 'N' }, // calculated
  { name: 'reserved2', start: 84, length: 18, type: 'N', constant: '000000000000000000' },
  { name: 'sourceAmount', start: 102, length: 15, type: 'N' }, // batch total (calculated)
  { name: 'reserved3', start: 117, length: 15, type: 'N', constant: '000000000000000' },
  { name: 'reserved4', start: 132, length: 15, type: 'N', constant: '000000000000000' },
  { name: 'reserved5', start: 147, length: 15, type: 'N', constant: '000000000000000' },
  { name: 'reserved6', start: 162, length: 7, type: 'F' },
];

// TC92 (file trailer) has an identical shape to TC91 (batch trailer);
// only the transaction code constant differs.
const TC92 = TC91.map((f) =>
  f.name === 'transactionCode' ? { ...f, constant: '92' } : { ...f }
);

module.exports = {
  RECORD_LENGTH,
  TCR0,
  TCR1,
  TCR5,
  TCR4,
  TC90,
  TC91,
  TC92,
};
